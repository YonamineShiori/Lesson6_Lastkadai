class Book < ApplicationRecord
  # userと関連付け
  belongs_to :user
  
  # バリテーション
  validates :title, presence: true
  validates :body, presence: true, length: { maximum: 200 }

end
