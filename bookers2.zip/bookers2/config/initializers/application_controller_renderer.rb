# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '7842577b3c09d110e505338b5439ffe54a7f70b7cf0da86019a7dd32dd5515c1a7828362d86463d37fdf466cb7424cada8776ee0d196e71061a8380973095e74'